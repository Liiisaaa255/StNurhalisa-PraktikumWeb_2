<main>
    <div class="container-fluid px-4">
        <h1 class="mt-4"><?= $title ?></h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item"><a href="<?php echo site_url('barang') ?>">Barang </a></li>
            <li class="breadcrumb-item active"><?php echo $title ?></li>
    </ol>
    <div class="card mb-4">
        <div class="card-body">
            <?php if (!$barang): ?>
                <div class="alert alert-danger">Data barang tidak ditemukan.</div>
            <?php else: ?>
                <form action="<?php echo site_url('barang/save') ?>" method="post" >
            <?php endif; ?>
            <div class="mb-3">
                <label>Barkode <code>*</code></label>
                <input class="form-control" type="hidden" name="id" value="<?=$barang->id;?>" required />
                <input class="form-control" name="barkode" value="<?=$barang->barkode;?>" type="text" placeholder="Barkode">
            </div>
            <div class="mb-3">
                <label>Nama Barang <code>*</code></label>
                <input class="form-control" name="name" value="<?=$barang->name;?>" type="text" placeholder="Nama Barang">
            </div>
            <div class="mb-3">
                <label>Harga Beli <code>*</code></label>
                <input class="form-control" name="harga_beli" type="number" value="<?= $barang->harga_beli ?>" required>
            </div>
            <div class="mb-3">
                <label>Harga Jual <code>*</code></label>
                <input class="form-control" name="harga_jual" type="number" value="<?= $barang->harga_jual ?>" required>
            </div>
            <div class="mb-3">
                <label>Stok <code>*</code></label>
                <input class="form-control" name="stok" value="<?=$barang->stok;?>" type="text" placeholder="Stok" disabled>
            </div>
            <div class="mb-3">
                <label>Kategori <code>*</code></label>
                <select name="kategori" class="form-control" required>
                    <?php foreach($kategori as $k): ?>
                        <option value="<?= $k['id'] ?>" <?= ($barang->kategori_id == $k['id']) ? 'selected' : '' ?>>
                            <?= $k['name'] ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="mb-3">
                <label>Satuan <code>*</code></label>
                <select name="satuan" class="form-control" required>
                    <?php foreach($satuan as $s): ?>
                        <option value="<?= $s['id'] ?>" <?= ($barang->satuan_id == $s['id']) ? 'selected' : '' ?>>
                            <?= $s['name'] ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="mb-3">
                <label>Supplier <code>*</code></label>
                <select name="supplier" class="form-control" required>
                    <?php foreach($supplier as $sup): ?>
                        <option value="<?= $sup['id'] ?>" <?= ($barang->supplier_id == $sup['id']) ? 'selected' : '' ?>>
                            <?= $sup['name'] ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

                <button class="btn btn-warning" type="submit"><i class="fas fa-edit"></i> Update</button>
        </form>
        </div>
        </div>
        <div style="height: 100vh"></div>
    </div>
</main>