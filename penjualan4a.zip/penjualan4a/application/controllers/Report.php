<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Report extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('pdf');
    }

    public function laporan()
    {
        $data = array(
            'title' => 'Tambah Laporan Data kustomer',
            'content' => 'report/laporan'
        );
        $this->load->view('template/main', $data);
    }

    public function kustomerlap()
    {
        $pdf = new FPDF('P','mm','A4');
        $pdf->AddPage();
        $pdf->SetFont('Times','B',18);
        $pdf->SetFont('Times','B',14);
        $pdf->Cell(0,5,'LAPORAN DATA KUSTOMER',0,1,'C');
        $pdf->Cell(30,8,'',0,1);
        $pdf->SetFont('Times','B',9);
        $pdf->Cell(7,6,'NO',1,0,'C');
        $pdf->Cell(37,6,'NIK',1,0,'C');
        $pdf->Cell(37,6,'NAMA CUSTOMER',1,0,'C');
        $pdf->Cell(30,6,'TELP',1,0,'C');
        $pdf->Cell(45,6,'ALAMAT',1,1,'C');
        $i=1;
        $data = $this->db->get('kustomer')->result_array();
        foreach($data as $d){
            $pdf->SetFont('Times','',9);
            $pdf->Cell(7,6,$i++,1,0);
            $pdf->Cell(37,6,$d['id'],1,0);
            $pdf->Cell(37,6,$d['nik'],1,0);
            $pdf->Cell(37,6,$d['name'],1,0);
            $pdf->Cell(30,6,$d['telp'],1,0);
            $pdf->Cell(45,6,$d['alamat'],1,1);
        }
        $pdf->SetFont('Times','',10);
        $pdf->Output('laporan_customer.pdf','I');
    }

    public function headerlap()
    {
        $this->load->view('kustomer/report_header_only');
    }

public function kustomerfull()
{
    ob_start();
    $this->load->library('pdf');
    $this->load->database();

    $query = $this->db->get('kustomer');
    $data_kustomer = $query->result();

    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Times','',12);

    $this->add_pdf_header($pdf);

    $pdf->SetFont('Times','B',12);
    $pdf->Cell(0,10,'LAPORAN DATA CUSTOMER',0,1,'C');
    $pdf->Ln(2);

    $pdf->SetFont('Times','B',10);
    $pdf->Cell(10,10,'NO',1,0,'C');
    $pdf->Cell(35,10,'NIK',1,0,'C');
    $pdf->Cell(40,10,'NAMA CUSTOMER',1,0,'C');
    $pdf->Cell(40,10,'TELP',1,0,'C');
    $pdf->Cell(60,10,'ALAMAT',1,1,'C');

    $pdf->SetFont('Times','',10);
    $no = 1;
    foreach ($data_kustomer as $row) {
        $pdf->Cell(10,10,$no++,1,0,'C');
        $pdf->Cell(35,10,$row->nik,1);
        $pdf->Cell(40,10,$row->name,1);
        $pdf->Cell(40,10,$row->telp,1);
        $pdf->Cell(60,10,$row->alamat,1);
        $pdf->Ln();
    }

    ob_end_clean();
    $pdf->Output('I', 'laporan_kustomer.pdf');
}

    private function add_pdf_header($pdf)
{
    $pdf->Image('./assets/img/cart.png',10,6,30);
    $pdf->Cell(25);
    $pdf->SetFont('Times','B',20);
    $pdf->Cell(0,5,'KOPERASI HARUM MANIS BERSATU',0,1,'C');
    $pdf->Cell(25);
    $pdf->SetFont('Times','B',10);
    $pdf->Cell(0,5,'Website : WWW.HARUMBERSATU.COM / E-Mail : admin@harumbersatu.com',0,1,'C');
    $pdf->Cell(25);
    $pdf->Cell(0,5,'Banjarmasin Utara Telp. / Fax : 081349685149 / KOPERASI HARUM MANIS BERSATU',0,1,'C');

    $pdf->SetLineWidth(1);
    $pdf->Line(10,36,197,36);
    $pdf->SetLineWidth(0);
    $pdf->Line(10,37,197,37);
    $pdf->Cell(30,17,'',0,1);
}

public function kustomerkustom()
{
    ob_start();
    $this->load->library('pdf');
    $this->load->database();

    $query = $this->db->get('kustomer');
    $data_kustomer = $query->result();

    $pdf = new FPDF();
    $pdf->AddPage();

    $pdf->Image('./assets/img/cart.png', 10, 6, 30);
    $pdf->Cell(25);
    $pdf->SetFont('Times', 'B', 20);
    $pdf->Cell(0, 5, 'KOPERASI HARUM MANIS BERSATU', 0, 1, 'C');

    $pdf->Cell(25);
    $pdf->SetFont('Times', 'B', 10);
    $pdf->Cell(0, 5, 'Website : WWW.HARUMBERSATU.COM / E-Mail : admin@harumbersatu.com', 0, 1, 'C');

    $pdf->Cell(25);
    $pdf->Cell(0, 5, 'Banjarmasin Utara Telp. / Fax : 081349685149 / KOPERASI HARUM MANIS BERSATU', 0, 1, 'C');

    $pdf->SetLineWidth(1);
    $pdf->Line(10, 36, 197, 36);
    $pdf->SetLineWidth(0);
    $pdf->Line(10, 37, 197, 37);
    $pdf->Cell(30, 17, '', 0, 1);

    $pdf->SetFont('Times', 'B', 12);
    $pdf->Cell(0, 10, 'LAPORAN DATA CUSTOMER', 0, 1, 'C');
    $pdf->Ln(2);

    $pdf->SetFont('Times', 'B', 10);
    $pdf->Cell(10, 10, 'NO', 1, 0, 'C');
    $pdf->Cell(35, 10, 'NIK', 1, 0, 'C');
    $pdf->Cell(40, 10, 'NAMA CUSTOMER', 1, 0, 'C');
    $pdf->Cell(40, 10, 'TELP', 1, 0, 'C');
    $pdf->Cell(60, 10, 'ALAMAT', 1, 1, 'C');

    $pdf->SetFont('Times', '', 10);
    $no = 1;
    foreach ($data_kustomer as $row) {
        $pdf->Cell(10, 10, $no++, 1, 0, 'C');
        $pdf->Cell(35, 10, $row->nik, 1);
        $pdf->Cell(40, 10, $row->name, 1);
        $pdf->Cell(40, 10, $row->telp, 1);
        $pdf->Cell(60, 10, $row->alamat, 1);
        $pdf->Ln();
    }

    ob_end_clean();
    $pdf->Output('I', 'laporan_kustomer_kustom.pdf');
}

}
