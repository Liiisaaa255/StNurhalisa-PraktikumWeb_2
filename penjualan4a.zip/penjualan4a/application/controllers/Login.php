<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->model('User_model');
    }

    public function index()
    {
        $this->form_validation->set_rules('email', 'Email', 'required|trim');
        $this->form_validation->set_rules('password', 'Password', 'required|trim');
        $this->load->view('login/index');
    }

    public function doLogin()
    {
        $email = $this->input->post('email', true);
        $password = $this->input->post('password', true);
        $user = $this->User_model->getByEmail($email);
        if ($user) {
            if (password_verify($password, $user->password)) { 
                $data = [
                    'id'       => $user->id,
                    'email'    => $user->email,
                    'username' => $user->username,
                    'role'     => $user->role
                ];
                $this->session->set_userdata($data);
                $this->_updateLastLogin($user->id);

                if ($user->role == 'PEMILIK') {
                    redirect('menu');
                } else if ($user->role == 'ADMIN') {
                    redirect('user');
                } else if ($user->role == 'KASIR') {
                    redirect('kasir');
                } else {
                    redirect('login');
                }

            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert"><b>Error:</b> Password salah.</div>');
                redirect('login');
            }

        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert"><b>Error:</b> User tidak terdaftar atau tidak aktif.</div>');
            redirect('login');
        }
    }

    private function _updateLastLogin($userid)
    {
        $sql = "UPDATE user SET last_login = NOW() WHERE id = $userid";
        $this->db->query($sql);
    }
}
