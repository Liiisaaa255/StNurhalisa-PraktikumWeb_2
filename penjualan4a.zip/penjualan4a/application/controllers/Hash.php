<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Hash extends CI_Controller {

    public function index()
    {
        $plain = 'admin123'; // <- ini password asli
        echo "Password asli: $plain<br>";
        echo "Hash-nya: " . password_hash($plain, PASSWORD_DEFAULT);
    }
}
