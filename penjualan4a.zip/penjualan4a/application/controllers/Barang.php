<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Barang extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Barang_model');
        $this->load->library('form_validation');
    }
    public function index()
    {
        $data = array(
            'title'     => 'Dashboard',
            'userlog'   => infoLogin(),
            'barang'    => $this->Barang_model->getAll(),
            'content'   => 'barang/index'
        );
        $this->load->view('template/main', $data);
    }

    public function add()
    {
        $data['title'] = 'Tambah Barang';
        $data['kategori'] = $this->Barang_model->getKategori();
        $data['satuan'] = $this->Barang_model->getSatuan();
        $data['supplier'] = $this->Barang_model->getSupplier();
        $data['content'] = 'barang/add_form'; 
        $this->load->view('template/main', $data);
    }

    public function save()
    {
        $id = $this->input->post('id');
        if ($id) {
            $this->Barang_model->update($id);
            $this->session->set_flashdata("success", "Data Barang Berhasil Diupdate");
        } else {
            $this->Barang_model->save();
            $this->session->set_flashdata("success", "Data Barang Berhasil Disimpan");
        }
        redirect('barang');
    }

    public function edit($id)
    {
        $data['title'] = 'Edit Barang';
        $data['barang'] = $this->Barang_model->getById($id); 
        $data['kategori'] = $this->Barang_model->getKategori();
        $data['satuan'] = $this->Barang_model->getSatuan();
        $data['supplier'] = $this->Barang_model->getSupplier();
        $data['content'] = 'barang/edit_form';
        $this->load->view('template/main', $data);
    }

        public function getedit($id)
    {
        $data['title'] = 'Update Data Barang';
        $data['kategori'] = $this->Barang_model->getKategori();
        $data['satuan'] = $this->Barang_model->getSatuan();
        $data['supplier'] = $this->Barang_model->getSupplier();
        $data['barang'] = $this->Barang_model->getById($id); 
        $data['content'] = 'barang/edit_form';
        $this->load->view('template/main', $data);
    }
}
